import React, { Component } from "react";
import "./styles.css";
import axios from "axios";
import Cards from "/src/Cards/Cards.js";
import Charts from "/src/Charts/Charts.js";
import CountrySelector from "/src/CountrySelector/CountrySelector.js";
import classes from "/src/OurStyle.module.css";
import { Paper } from "@material-ui/core";

class App extends Component {
  state = {
    data: {
      confirmed: 0,
      recovered: 0,
      deaths: 0,
      lastUpdate: ""
    },
    dailyData: {
      confirmed: [],
      deaths: [],
      reportDate: []
    },
    countries: {
      counts: []
    },
    countrySelected: "Global",
    countryData: {
      confirmed: 0,
      recovered: 0,
      deaths: 0
    }
  };

  componentDidMount() {
    axios
      .get("https://covid19.mathdro.id/api")
      .then(response => {
        this.setState({
          data: {
            confirmed: Number(response.data.confirmed.value),
            recovered: response.data.recovered.value,
            deaths: response.data.deaths.value,
            lastUpdate: response.data.lastUpdate
          }
        });
      })
      .catch(err => {
        this.setState({ data: err });
      });

    axios
      .get("https://covid19.mathdro.id/api/daily")
      .then(res => {
        let arr1 = [];
        let arr2 = [];
        let arr3 = [];
        res.data.map(comp => {
          arr1.push(comp.totalConfirmed);
          arr2.push(comp.deaths.total);
          arr3.push(comp.reportDate);

          return true;
        });
        this.setState({
          dailyData: {
            confirmed: arr1,
            deaths: arr2,
            reportDate: arr3
          }
        });
      })
      .catch(err => {
        console.log(err);
      });

    axios
      .get("https://covid19.mathdro.id/api/countries")
      .then(res => {
        console.log(res);
        let arr5 = [];
        res.data.countries.map(resp => {
          arr5.push(resp.name);
        });

        this.setState({ countries: { counts: arr5 } });
      })
      .catch(err => {
        console.log(err);
      });

    /*axios
      .get(
        "https://covid19.mathdro.id/api/countries" +
          "/" +
          this.state.countrySelected
      )
      .then(res => {
        console.log(res);
        this.setState({
          countryData: {
            confirmed: res.data.confirmed.value,
            recovered: res.data.recovered.value,
            deaths: res.data.deaths.value
          }
        });

        console.log(this.state.countryData);
      })
      .catch(err => {
        console.log(err);
      });*/
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.countrySelected !== this.state.countrySelected) {
      if (this.state.countrySelected !== "Global") {
        axios
          .get(
            "https://covid19.mathdro.id/api/countries" +
              "/" +
              this.state.countrySelected
          )
          .then(res => {
            console.log(res);
            this.setState({
              countryData: {
                confirmed: res.data.confirmed.value,
                recovered: res.data.recovered.value,
                deaths: res.data.deaths.value
              }
            });

            console.log(this.state.countryData);
          })
          .catch(err => {
            console.log(err);
          });
      }
    }
  }

  changeCountryHandler = event => {
    console.log(event.target.value);
    this.setState({ countrySelected: event.target.value });
  };

  render() {
    return (
      <div>
        <div style={{ marginBottom: "50px" }}>
          <Paper
            elevation={6}
            square={true}
            style={{ backgroundColor: "#5CDB95", opacity: "0.7" }}
            className={classes.Seer}
            variant="outlined"
          >
            COVID19 TRACKER
          </Paper>
        </div>
        <div className={classes.container}>
          <Cards data={this.state.data} />
          <CountrySelector
            changed={this.changeCountryHandler}
            data={this.state.countries.counts}
          />
          <Charts
            dailyData={this.state.dailyData}
            selectedCountry={this.state.countrySelected}
            countryData={this.state.countryData}
          />
        </div>
      </div>
    );
  }
}

export default App;
