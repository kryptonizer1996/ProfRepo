import React from "react";
import { Line, Bar } from "react-chartjs-2";
import classes from "/src/Charts/Charts.module.css";

const charts = props => {
  const barChart = (
    <Bar
      data={{
        labels: ["Infected", "Recovered", "Deaths"],
        datasets: [
          {
            label: "Number of People",
            backgroundColor: [
              "rgba(255, 0, 0,0.65)",
              "rgba(0, 255, 0,0.65)",
              "rgba(0, 0, 255,0.65)"
            ],
            data: [
              props.countryData.confirmed,
              props.countryData.recovered,
              props.countryData.deaths
            ]
          }
        ]
      }}
      options={{
        Legend: { display: false },
        title: { display: true, text: props.selectedCountry }
      }}
    />
  );

  const lineChart = (
    <Line
      data={{
        labels: props.dailyData.reportDate,
        datasets: [
          {
            data: props.dailyData.confirmed,
            label: "infected",
            borderColor: "blue"
          },
          {
            data: props.dailyData.deaths,
            label: "deaths",
            borderColor: "red"
          }
        ]
      }}
    />
  );

  let update = <div style={{ width: "70%" }}>{barChart}</div>;

  if (props.selectedCountry === "Global") {
    update = <div style={{ width: "70%" }}>{lineChart}</div>;
  }

  return <div className={classes.Charts}>{update}</div>;
};

export default charts;
