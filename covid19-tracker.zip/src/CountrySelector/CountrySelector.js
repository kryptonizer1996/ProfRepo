import React from "react";
import { NativeSelect, FormControl } from "@material-ui/core";
import classes from "/src/CountrySelector/CountrySelector.module.css";

const countrySelector = props => {
  return (
    <FormControl className={classes.formControl}>
      <NativeSelect onChange={props.changed}>
        <option value="Global">Global</option>
        {props.data.map((res, i) => (
          <option key={i} value={res}>
            {res}
          </option>
        ))}
      </NativeSelect>
    </FormControl>
  );
};

export default countrySelector;
